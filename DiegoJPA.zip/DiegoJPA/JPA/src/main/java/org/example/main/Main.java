package org.example.main;

import org.example.menu.MenuFutbolDAO;

public class Main {
    public static void main(String[] args) {
        MenuFutbolDAO menu = new MenuFutbolDAO();
        menu.mostrarMenu();
    }
}
