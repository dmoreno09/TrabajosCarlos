package org.example.menu;

import org.example.mapeo.Futbol;
import org.example.mapeo.CategoriaFutbol;
import org.hibernate.HibernateException;

import java.util.List;
import java.util.Scanner;

public class MenuFutbolDAO {

    private final Scanner scn = new Scanner(System.in);
    private final FutbolDAO futbolDAO = new FutbolDAO();

    public MenuFutbolDAO() {
    }

    public void mostrarMenu() {
        int opcion = 0;
        while (opcion != 8) {
            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Crear jugador");
            System.out.println("2. Buscar jugador por ID");
            System.out.println("3. Editar jugador");
            System.out.println("4. Eliminar jugador");
            System.out.println("5. Listar todos los jugadores");
            System.out.println("6. Buscar jugadores por nombre");
            System.out.println("7. Filtrar jugadores por categoría");
            System.out.println("8. Salir");
            System.out.print("Introduzca la opción que quiere realizar: ");

            try {
                opcion = scn.nextInt();
                scn.nextLine();  // Limpiar el buffer

                switch (opcion) {
                    case 1 -> crearJugador();
                    case 2 -> buscarJugador();
                    case 3 -> editarJugador();
                    case 4 -> eliminarJugador();
                    case 5 -> listarTodosLosJugadores();
                    case 6 -> buscarJugadoresPorNombre();
                    case 7 -> filtrarJugadoresPorCategoria();
                    case 8 -> System.out.println("Saliendo del programa.");
                    default -> System.out.println("Opción no válida. Por favor, intente de nuevo.");
                }
            } catch (HibernateException e) {
                System.err.println("Error de base de datos: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Error inesperado: " + e.getMessage());
                scn.nextLine();  // Limpiar el buffer si hay errores de entrada
            }
        }
    }

    private void crearJugador() throws HibernateException {
        System.out.print("Introduzca el nombre del jugador: ");
        String nombre = scn.nextLine();
        System.out.print("Introduzca el nivel del jugador: ");
        int nivel = scn.nextInt();
        scn.nextLine();
        System.out.print("Introduzca el ID de la categoría: ");
        int categoriaId = scn.nextInt();
        scn.nextLine();

        CategoriaFutbol categoria = new CategoriaFutbol();
        categoria.setCategoriaId(categoriaId);

        Futbol jugador = new Futbol(nombre, nivel, categoria);
        futbolDAO.crearJugador(jugador);
        System.out.println("Jugador creado con éxito: " + jugador);
    }

    private void buscarJugador() throws HibernateException {
        System.out.print("Introduzca el ID del jugador que desea buscar: ");
        int id = scn.nextInt();
        scn.nextLine();
        Futbol jugador = futbolDAO.obtenerJugadorPorId(id);
        if (jugador != null) {
            System.out.println("Jugador encontrado: " + jugador);
        } else {
            System.out.println("No se encontró jugador con ID: " + id);
        }
    }

    private void editarJugador() throws HibernateException {
        System.out.print("Introduzca el ID del jugador que desea editar: ");
        int id = scn.nextInt();
        scn.nextLine();
        Futbol jugador = futbolDAO.obtenerJugadorPorId(id);

        if (jugador != null) {
            System.out.print("Introduzca el nuevo nombre del jugador: ");
            String nuevoNombre = scn.nextLine();
            System.out.print("Introduzca el nuevo nivel del jugador: ");
            int nuevoNivel = scn.nextInt();
            scn.nextLine();
            System.out.print("Introduzca el nuevo ID de la categoría: ");
            int nuevaCategoriaId = scn.nextInt();
            scn.nextLine();

            CategoriaFutbol nuevaCategoria = new CategoriaFutbol();
            nuevaCategoria.setCategoriaId(nuevaCategoriaId);

            jugador.setNombre(nuevoNombre);
            jugador.setNivel(nuevoNivel);
            jugador.setCategoria(nuevaCategoria);

            futbolDAO.actualizarJugador(jugador);
            System.out.println("Jugador actualizado con éxito: " + jugador);
        } else {
            System.out.println("No se encontró jugador con ID: " + id);
        }
    }

    private void eliminarJugador() throws HibernateException {
        System.out.print("Introduzca el ID del jugador que desea eliminar: ");
        int id = scn.nextInt();
        scn.nextLine();

        Futbol jugador = futbolDAO.obtenerJugadorPorId(id);
        if (jugador != null) {
            futbolDAO.eliminarJugador(jugador);
            System.out.println("Jugador eliminado con éxito.");
        } else {
            System.out.println("No se encontró jugador con ID: " + id);
        }
    }

    private void listarTodosLosJugadores() throws HibernateException {
        List<Futbol> listaJugadores = futbolDAO.listarJugadores();
        if (listaJugadores.isEmpty()) {
            System.out.println("No se encontraron jugadores.");
        } else {
            System.out.println("Listado de jugadores:");
            listaJugadores.forEach(System.out::println);
        }
    }

    private void buscarJugadoresPorNombre() throws HibernateException {
        System.out.print("Introduzca el nombre del jugador a buscar: ");
        String nombre = scn.nextLine();
        List<Futbol> listaJugadores = futbolDAO.buscarJugadorPorNombre(nombre);
        if (listaJugadores.isEmpty()) {
            System.out.println("No se encontraron jugadores con ese nombre.");
        } else {
            System.out.println("Jugadores encontrados:");
            listaJugadores.forEach(System.out::println);
        }
    }

    private void filtrarJugadoresPorCategoria() throws HibernateException {
        System.out.print("Introduzca el ID de la categoría: ");
        int categoriaId = scn.nextInt();
        scn.nextLine();
        List<Futbol> listaJugadores = futbolDAO.filtrarJugadoresPorCategoria(categoriaId);
        if (listaJugadores.isEmpty()) {
            System.out.println("No se encontraron jugadores para esa categoría.");
        } else {
            System.out.println("Jugadores de la categoría " + categoriaId + ":");
            listaJugadores.forEach(System.out::println);
        }
    }
}


