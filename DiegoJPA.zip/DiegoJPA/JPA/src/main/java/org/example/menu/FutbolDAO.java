package org.example.menu;


import org.example.mapeo.Futbol;
import org.example.conexion.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class FutbolDAO {

    public void crearJugador(Futbol jugador) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(jugador);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        } finally {
            session.close();
        }
    }

    public Futbol obtenerJugadorPorId(int id) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            return session.get(Futbol.class, id);
        } finally {
            session.close();
        }
    }

    public void actualizarJugador(Futbol jugador) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(jugador);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        } finally {
            session.close();
        }
    }

    public void eliminarJugador(Futbol jugador) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(jugador);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        } finally {
            session.close();
        }
    }

    public List<Futbol> listarJugadores() throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Futbol", Futbol.class).list();
        } finally {
            session.close();
        }
    }

    public List<Futbol> buscarJugadorPorNombre(String nombre) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Futbol f WHERE f.nombre LIKE :nombre", Futbol.class)
                    .setParameter("nombre", "%" + nombre + "%")
                    .list();
        } finally {
            session.close();
        }
    }

    public List<Futbol> filtrarJugadoresPorCategoria(int categoriaId) throws HibernateException {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Futbol f WHERE f.categoria.id = :categoriaId", Futbol.class)
                    .setParameter("categoriaId", categoriaId)
                    .list();
        } finally {
            session.close();
        }
    }
}
