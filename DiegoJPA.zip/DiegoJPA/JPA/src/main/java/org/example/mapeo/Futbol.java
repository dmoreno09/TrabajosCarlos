package org.example.mapeo;

import javax.persistence.*;

@Entity
@Table(name = "jugadores")
public class Futbol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "nivel")
    private int nivel;

    // Relación muchos a uno con CategoriaFutbol
    @ManyToOne
    @JoinColumn(name = "categoria_id", referencedColumnName = "id")
    private CategoriaFutbol categoria;

    // Constructor con parámetros
    public Futbol(String nombre, int nivel, CategoriaFutbol categoria) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.categoria = categoria;
    }

    // Constructor vacío para JPA
    public Futbol() {
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public CategoriaFutbol getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaFutbol categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Futbol{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", nivel=" + nivel +
                ", categoria=" + (categoria != null ? categoria.getNombre() : "Sin categoría") +
                '}';
    }
}
